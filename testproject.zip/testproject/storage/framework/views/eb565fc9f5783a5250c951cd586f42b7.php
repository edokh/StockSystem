<?php $__env->startSection('title', 'Create Faculty'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row ">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Create Faculty</div>

                <div class="card-body">
                    <form action="<?php echo e(route('faculties.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" name="name" id="name" class="form-control" required>
                        </div>


                        <button type="submit" class="btn btn-primary">Create</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/faculties/create.blade.php ENDPATH**/ ?>