<?php $__env->startSection('title', 'Edit Department'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Department</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('departments.update', $department->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="name">Name:</label>
                            <input type="text" class="form-control" id="name" name="name"
                                value="<?php echo e($department->name); ?>" required>
                        </div>
                        <div class="form-group" style="display: none">
                            <label for="department_id">Department:</label>
                            <input type="text" class="form-control" id="department_id" name="department_id"
                                value="<?php echo e($department->department_id); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="faculty_id">Faculty:</label>
                            <select class="form-control" id="faculty_id" name="faculty_id" required>
                                <?php $__currentLoopData = $faculties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faculty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($faculty->id); ?>"
                                        <?php echo e($department->faculty_id == $faculty->id ? 'selected' : ''); ?>><?php echo e($faculty->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="<?php echo e(route('departments.show', $department->id)); ?>" class="btn btn-secondary">Cancel</a>

                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/departments/edit.blade.php ENDPATH**/ ?>