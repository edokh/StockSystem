<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />

    <!-- Styles -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    
    <style>
        body::before {
            content: "";
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.3);
            /* semi-transparent black */
            z-index: -1;
            /* put the layer behind the content */
        }
    </style>

</head>

<body class="bg-cover bg-center relative" style="background-image:url('/uoz.jpg')">
    <div>
        
        <div class="flex h-screen justify-center items-center">
            <div class="text-center">
                <h1 class="mb-16 text-6xl text-white">Welcome to UOZ state recording system</h1>

                <?php if(Route::has('login')): ?>
                    <div class="">
                        <?php if(auth()->guard()->check()): ?>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                    class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                                    Logout</button>

                            </form>

                            <!-- Authentication -->
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>"
                                class="rounded-lg bg-blue-500  px-8 py-3 font-bold uppercase tracking-wide text-white shadow-lg">
                                <i class="fas fa-sign-in-alt fa-fw mr-2"></i>Log
                                in</a>

                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/welcome.blade.php ENDPATH**/ ?>