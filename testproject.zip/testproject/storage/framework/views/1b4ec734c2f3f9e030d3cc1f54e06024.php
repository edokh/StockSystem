<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Device List</h4>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('devices.create')); ?>" class="btn btn-primary mb-3">Create Device</a>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Device Type</th>
                                <th>Room</th>
                                <th>Status</th>
                                <th>Properties</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $devices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $device): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($device->title); ?></td>
                                    <td><?php echo e($device->deviceType->name); ?></td>
                                    <td><?php echo e($device->room->number); ?> (<?php echo e($device->room->location); ?>)</td>
                                    <td><?php echo e($device->status); ?></td>
                                    <td><?php echo e($device->properties_about); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('devices.show', $device->id)); ?>" class="btn btn-primary">View</a>
                                        <a href="<?php echo e(route('devices.edit', $device->id)); ?>"
                                            class="btn btn-secondary">Edit</a>
                                        <form action="<?php echo e(route('devices.destroy', $device->id)); ?>" method="POST"
                                            class="d-inline-block">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this device?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/devices/index.blade.php ENDPATH**/ ?>