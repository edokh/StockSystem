<?php $__env->startSection('title', 'Faculty Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row  ">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Faculty Details</h4>
                </div>

                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <td>ID</td>
                                <td><?php echo e($device->id); ?></td>
                            </tr>

                            <tr>
                                <td>Name</td>
                                <td><?php echo e($device->title); ?></td>
                            </tr>
                            <tr>
                                <td>Device Type</td>
                                <td><?php echo e($device->deviceType->name); ?></td>
                            </tr>
                            <tr>
                                <td>Room</td>
                                <td><?php echo e($device->room->id); ?>-<?php echo e($device->room->location); ?></td>
                            </tr>
                            <tr>
                                <td>Status</td>
                                <td><?php echo e($device->status); ?></td>
                            </tr>
                            <tr>
                                <td>Properties About</td>
                                <td><?php echo e($device->properties_about); ?></td>
                            </tr>

                        </tbody>
                    </table>
                    <a href="<?php echo e(route('devices.edit', $device->id)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('devices.destroy', $device->id)); ?>" method="POST" style="display: inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/devices/show.blade.php ENDPATH**/ ?>