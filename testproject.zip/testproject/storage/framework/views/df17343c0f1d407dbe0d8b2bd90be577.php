<?php $__env->startSection('title', 'User Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>User Details</h4>
                </div>
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <td>ID</td>
                                <td><?php echo e($user->id); ?></td>
                            </tr>
                            <tr>
                                <td>Name</td>
                                <td><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <td>User Type</td>
                                <td><?php echo e(ucfirst($user->usertype)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('users.edit', $user)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('users.destroy', $user)); ?>" method="POST" style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/users/show.blade.php ENDPATH**/ ?>