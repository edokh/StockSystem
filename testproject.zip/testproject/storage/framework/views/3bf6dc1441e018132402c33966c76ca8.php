 
 <?php $__env->startSection('title', 'Create User'); ?>

 <?php $__env->startSection('content'); ?>
     <div class="row">
         <div class="col-md-12">
             <div class="card">
                 <div class="card-header">
                     <h4>Create User</h4>
                 </div>
                 <div class="card-body">
                     <form action="<?php echo e(route('users.store')); ?>" method="POST">
                         <?php echo csrf_field(); ?>
                         <div class="form-group">
                             <label for="name">Name</label>
                             <input type="text" class="form-control" id="name" name="name"
                                 placeholder="Enter name" required>
                         </div>
                         <div class="form-group">
                             <label for="email">Email address</label>
                             <input type="email" class="form-control" id="email" name="email"
                                 placeholder="Enter email" required>
                         </div>
                         <div class="form-group">
                             <label for="password">Password</label>
                             <input type="password" class="form-control" id="password" name="password"
                                 placeholder="Enter password" required>
                         </div>
                         <div class="form-group">
                             <label for="usertype">Usertype</label>
                             <select class="form-control" id="usertype" name="usertype" required>
                                 <option value="">-- Select Usertype --</option>
                                 <option value="admin">Admin</option>
                                 <option value="user">User</option>
                             </select>
                         </div>
                         <button type="submit" class="btn btn-primary">Create</button>
                         <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary">Cancel</a>
                     </form>
                 </div>
             </div>
         </div>
     </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/users/create.blade.php ENDPATH**/ ?>