<?php $__env->startSection('title', 'Rooms'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Rooms</h4>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('rooms.create')); ?>" class="btn btn-primary">Create Room</a>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Number</th>
                                <th>Location</th>
                                <th>Department</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($room->number); ?></td>
                                    <td><?php echo e($room->location); ?></td>
                                    <td><?php echo e($room->department->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('rooms.show', $room->id)); ?>" class="btn btn-primary">View</a>
                                        <a href="<?php echo e(route('rooms.edit', $room->id)); ?>" class="btn btn-secondary">Edit</a>
                                        <form class="d-inline-block" action="<?php echo e(route('rooms.destroy', $room->id)); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger" type="submit"
                                                onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/rooms/index.blade.php ENDPATH**/ ?>