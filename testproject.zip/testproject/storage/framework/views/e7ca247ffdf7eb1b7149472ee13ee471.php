<?php $__env->startSection('title', 'Device Types'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Device Types</h4>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('device-types.create')); ?>" class="btn btn-primary mb-3">Create Device Type</a>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $deviceTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deviceType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($deviceType->id); ?></td>
                                    <td><?php echo e($deviceType->name); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('device-types.show', ['device_type' => $deviceType->id])); ?>"
                                            class="btn   btn-primary">View</a>
                                        <a href="<?php echo e(route('device-types.edit', ['device_type' => $deviceType->id])); ?>"
                                            class="btn   btn-secondary">Edit</a>
                                        <form
                                            action="<?php echo e(route('device-types.destroy', ['device_type' => $deviceType->id])); ?>"
                                            method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this user?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/device_types/index.blade.php ENDPATH**/ ?>