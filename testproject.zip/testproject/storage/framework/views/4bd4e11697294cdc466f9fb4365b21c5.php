<?php $__env->startSection('title', 'Teams'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Teams</h4>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('teams.create')); ?>" class="btn btn-primary mb-3">Create Team</a>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Type</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($team->id); ?></td>
                                    <td><?php echo e($team->name); ?></td>
                                    <td><?php echo e($team->team_type); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('teams.show', $team->id)); ?>" class="btn btn-primary">View</a>
                                        <a href="<?php echo e(route('teams.edit', $team->id)); ?>" class="btn btn-secondary">Edit</a>
                                        <form class="d-inline-block" action="<?php echo e(route('teams.destroy', $team->id)); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/teams/index.blade.php ENDPATH**/ ?>