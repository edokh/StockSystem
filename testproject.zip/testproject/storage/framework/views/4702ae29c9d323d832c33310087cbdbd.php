<?php $__env->startSection('title', 'Team Members'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row  ">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Team Members</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Staff</th>
                                <th scope="col">Team</th>
                                <th scope="col">Role</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teamMember): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($teamMember->id); ?></th>
                                    <td><?php echo e($teamMember->user); ?> - <?php echo e($teamMember->department); ?></td>
                                    <td><?php echo e($teamMember->team); ?></td>
                                    <td><?php echo e($teamMember->role); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('team-members.edit', $teamMember->id)); ?>"
                                            class="btn btn-primary">Edit</a>
                                        <form method="POST" action="<?php echo e(route('team-members.destroy', $teamMember->id)); ?>"
                                            style="display: inline-block;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this team member?')">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('team-members.create')); ?>" class="btn btn-primary">Create Team</a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/team_members/index.blade.php ENDPATH**/ ?>