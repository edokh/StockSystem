<?php $__env->startSection('title', 'Edit Team'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Team</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('teams.update', $team)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name"
                                value="<?php echo e($team->name); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="team_type">Team Type</label>
                            <select class="form-control" id="team_type" name="team_type" required>
                                <option value="">-- Select team_type --</option>
                                <option value="faculty" <?php if($team->team_type == 'faculty'): ?> selected <?php endif; ?>>Faculty</option>
                                <option value="department" <?php if($team->team_type == 'department'): ?> selected <?php endif; ?>>Department
                                </option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="<?php echo e(route('teams.show', $team)); ?>" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/teams/edit.blade.php ENDPATH**/ ?>