<!-- Sidebar -->
<style>
    .nav-span {
        font-size: 1rem !important;
        color: #F7F7F7
    }

    i {
        font-size: 1rem !important;
        color: #F1F1F1 !important;
    }

    .active {
        color: white !important;
        font-weight: 700
    }
</style>
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/cp">

        <div class="sidebar-brand-text mx-3">state recording system</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <li class="nav-item">
            <a class="nav-link <?php if(Request::is('cp/users*')): ?> active <?php endif; ?> " href="/cp/users">
                <i class="fas fa-users <?php if(Request::is('cp/users*')): ?> active <?php endif; ?> "></i>
                <span class="nav-span ">Users</span>
            </a>
        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/faculties">
                <i class="fas fa-university <?php if(Request::is('cp/faculties*')): ?> active <?php endif; ?> "></i>
                <span class="nav-span <?php if(Request::is('cp/faculties*')): ?> active <?php endif; ?> ">Faculties</span></a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/departments">
                <i class="fas fa-building <?php if(Request::is('cp/departments*')): ?> active <?php endif; ?> "></i>
                <span class="nav-span <?php if(Request::is('cp/departments*')): ?> active <?php endif; ?> ">Departments</span></a>
        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/staff">
                <i class="fas fa-users-cog <?php if(Request::is('cp/staff*')): ?> active <?php endif; ?> "></i>
                <span class="nav-span <?php if(Request::is('cp/staff*')): ?> active <?php endif; ?> ">Staff</span></a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin', 'staff'])): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/rooms">
                <i class="fas fa-door-open <?php if(Request::is('cp/rooms*')): ?> active <?php endif; ?> "></i>
                <span class="nav-span <?php if(Request::is('cp/rooms*')): ?> active <?php endif; ?> ">Rooms</span></a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/device-types">
                <i class="material-icons <?php if(Request::is('cp/device-types*')): ?> active <?php endif; ?>"
                    style="font-size:36px">devices_other</i>
                <span class="nav-span <?php if(Request::is('cp/device-types*')): ?> active <?php endif; ?>">Device Types</span>
            </a>
        </li>
    <?php endif; ?>

    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin', 'staff'])): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/devices">
                <i class="material-icons <?php if(Request::is('cp/devices*')): ?> active <?php endif; ?>">devices</i>

                <span class="nav-span <?php if(Request::is('cp/devices*')): ?> active <?php endif; ?>">Devices</span></a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin'])): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/teams">
                <i class="fas fa-user-friends <?php if(Request::is('cp/teams*')): ?> active <?php endif; ?>"></i>
                <span class="nav-span <?php if(Request::is('cp/teams*')): ?> active <?php endif; ?>">Teams</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/cp/team-members">
                <i class="fas fa-id-badge <?php if(Request::is('cp/team-members*')): ?> active <?php endif; ?>"></i>
                <span class="nav-span <?php if(Request::is('cp/team-members*')): ?> active <?php endif; ?>">Team Members</span>
            </a>
        </li>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['admin', 'staff', 'maintainer'])): ?>
        <li class="nav-item">
            <a class="nav-link" href="/cp/reports">
                <i class="fas fa-file-alt <?php if(Request::is('cp/reports*')): ?> active <?php endif; ?>"></i>
                <span class="nav-span <?php if(Request::is('cp/reports*')): ?> active <?php endif; ?>">Reports</span>
            </a>
        </li>
    <?php endif; ?>


</ul>
<!-- End of Sidebar -->
<?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/dashboard/sidebar.blade.php ENDPATH**/ ?>