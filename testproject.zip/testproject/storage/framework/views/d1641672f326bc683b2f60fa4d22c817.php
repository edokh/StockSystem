<?php $__env->startSection('title', 'Deveice Type Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row  ">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Device Type Details</h4>
                </div>

                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>ID</th>
                                <td><?php echo e($deviceType->id); ?></td>
                            </tr>
                            <tr>
                                <th>Name</th>
                                <td><?php echo e($deviceType->name); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('device-types.edit', $deviceType)); ?>" class="btn btn-primary">Edit</a>
                    <form action="<?php echo e(route('device-types.destroy', $deviceType)); ?>" method="POST"
                        style="display: inline-block;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/device_types/show.blade.php ENDPATH**/ ?>