<?php $__env->startSection('title', 'Edit Device Type'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4><?php echo e(__('Edit Device Type')); ?></h4>
                </div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('device-types.update', $device_type->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group  ">
                            <label for="name"><?php echo e(__('Name')); ?></label>

                            <input id="name" type="text" class="form-control" name="name"
                                value="<?php echo e(old('name', $device_type->name)); ?>" required autocomplete="name" autofocus>


                        </div>

                        <button type="submit" class="btn btn-primary">Save</button>
                        <a href="<?php echo e(route('device-types.show', $device_type)); ?>" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.dashboardLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\eidok\Downloads\testproject\testproject\resources\views/device_types/edit.blade.php ENDPATH**/ ?>